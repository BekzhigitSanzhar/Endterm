package ru.tarayev;

import com.company.data.PostgresDB;
import com.company.data.interfaces.IDB;

import ru.tarayev.applications.Application;
import ru.tarayev.controllers.StudentController;
import ru.tarayev.controllers.TeacherController;

public class Main {
	public static void main(String[] args) {
		IDB idb = new PostgresDB();
		StudentController controller = new StudentController(idb);
		TeacherController tcontroller = new TeacherController(idb);
		Application app = new Application(controller, tcontroller);
		app.start();
	}
}
