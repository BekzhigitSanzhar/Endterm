package ru.tarayev.entity;

public class Teacher {
	private int id;
	private String name;
	private String password;
	private int points;
	private int idOfCourse;
	public Teacher(int id, String name, String password, int points, int idOfCourse) {
		super();
		this.id = id;
		this.name = name;
		this.password = password;
		this.points = points;
		this.idOfCourse = idOfCourse;
	}
	
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the points
	 */
	public int getPoints() {
		return points;
	}
	/**
	 * @param points the points to set
	 */
	public void setPoints(int points) {
		this.points = points;
	}
	/**
	 * @return the idOfCourse
	 */
	public int getIdOfCourse() {
		return idOfCourse;
	}
	/**
	 * @param idOfCourse the idOfCourse to set
	 */
	public void setIdOfCourse(int idOfCourse) {
		this.idOfCourse = idOfCourse;
	}
 

	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "Teacher [id=" + id + ", name=" + name + ", password=" + password + ", points=" + points
				+ ", idOfCourse=" + idOfCourse + "]";
	}
	
}
