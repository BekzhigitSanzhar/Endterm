package ru.tarayev.entity.quality;

public class Lecture {
	private int id;
	private String name;
	private int courseId;
	private int numberOfPoints;
	public Lecture(int id, String name, int courseId, int numberOfPoints) {
		super();
		this.id = id;
		this.name = name;
		this.courseId = courseId;
		this.numberOfPoints = numberOfPoints;
	}
	
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the courseId
	 */
	public int getCourseId() {
		return courseId;
	}
	/**
	 * @param courseId the courseId to set
	 */
	public void setCourseId(int courseId) {
		this.courseId = courseId;
	}
	/**
	 * @return the numberOfPoints
	 */
	public int getNumberOfPoints() {
		return numberOfPoints;
	}
	/**
	 * @param numberOfPoints the numberOfPoints to set
	 */
	public void setNumberOfPoints(int numberOfPoints) {
		this.numberOfPoints = numberOfPoints;
	}

	@Override
	public String toString() {
		return "Lecture [id=" + id + ", name=" + name + ", courseId=" + courseId + ", numberOfPoints=" + numberOfPoints
				+ "]";
	}
	
}
