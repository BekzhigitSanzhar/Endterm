package ru.tarayev.entity.quality;

import java.util.ArrayList;
import java.util.List;

public class Course {
	private int id;
	private String name;
	private int numberOfCredits;
	private List<Integer> idsOfLectures = new ArrayList<Integer>();
	public Course(int id, String name, int numberOfCredits) {
		super();
		this.id = id;
		this.name = name;
		this.numberOfCredits = numberOfCredits;
	}
	 
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the numberOfCredits
	 */
	public int getNumberOfCredits() {
		return numberOfCredits;
	}
	/**
	 * @param numberOfCredits the numberOfCredits to set
	 */
	public void setNumberOfCredits(int numberOfCredits) {
		this.numberOfCredits = numberOfCredits;
	}
	/**
	 * @return the idsOfLectures
	 */
	public List<Integer> getIdsOfLectures() {
		return idsOfLectures;
	}

	/**
	 * @param idsOfLectures the idsOfLectures to set
	 */
	public void setIdsOfLectures(List<Integer> idsOfLectures) {
		this.idsOfLectures = idsOfLectures;
	}

	@Override
	public String toString() {
		return "Course [id=" + id + ", name=" + name + ", numberOfCredits=" + numberOfCredits + ", idsOfLectures="
				+ idsOfLectures + "]";
	}
	 

	
	
	
}
