package ru.tarayev.entity;

import java.util.Arrays;
import java.util.List;

public class Student {
	private int id;
	private String name;
	private String password;
	private int points;
	private int numberOfLectures;
	private List<Integer> idOfCourses;
	public Student(int id, String name, String password, int points, int numberOfLectures, List<Integer> idOfCourses) {
		super();
		this.id = id;
		this.name = name;
		this.password = password;
		this.points = points;
		this.numberOfLectures = numberOfLectures;
		this.idOfCourses = idOfCourses;
	}
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}
	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}
	/**
	 * @return the points
	 */
	public int getPoints() {
		return points;
	}
	/**
	 * @param points the points to set
	 */
	public void setPoints(int points) {
		this.points = points;
	}
	/**
	 * @return the numberOfLectures
	 */
	public int getNumberOfLectures() {
		return numberOfLectures;
	}
	/**
	 * @param numberOfLectures the numberOfLectures to set
	 */
	public void setNumberOfLectures(int numberOfLectures) {
		this.numberOfLectures = numberOfLectures;
	}
	/**
	 * @return the idOfCourses
	 */
	public List<Integer> getIdOfCourses() {
		return idOfCourses;
	}
	/**
	 * @param idOfCourses the idOfCourses to set
	 */
	public void setIdOfCourses(List<Integer> idOfCourses) {
		this.idOfCourses = idOfCourses;
	}
	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", password=" + password + ", points=" + points
				+ ", numberOfLectures=" + numberOfLectures + ", idOfCourses=" + idOfCourses + "]";
	}
	 
	
}
