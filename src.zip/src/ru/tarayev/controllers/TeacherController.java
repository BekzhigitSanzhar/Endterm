package ru.tarayev.controllers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.company.data.interfaces.IDB;

import ru.tarayev.entity.Student;
import ru.tarayev.entity.Teacher;
import ru.tarayev.entity.quality.Lecture;

public class TeacherController {
	private IDB db;
	
	public TeacherController(IDB db) {
		this.db = db;
	}
	public Teacher getTeacher(int id) {
        Connection con = null;
        try {
            con = db.getConnection();
            String sql = "SELECT * FROM teachers WHERE teacher_id=?";
            PreparedStatement st = con.prepareStatement(sql);

            st.setInt(1, id);
            ResultSet rs = st.executeQuery();
            
            
            if (rs.next()) {
            	 
            	Teacher teacher = new Teacher(rs.getInt("teacher_id"), 
            			rs.getString("teacher_name"), rs.getString("teacher_password"),
            			rs.getInt("teacher_points"), rs.getInt("course_id"));
                return teacher;
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
        return null;
    }
	public void addLecture(Lecture lecture) {
        Connection con = null;
        try {
            con = db.getConnection();
            String sql = "INSERT INTO lectures(lecture_id, lecture_name, lecture_numberOfPoints, course_id) VALUES (?,?,?,?)";
            PreparedStatement st = con.prepareStatement(sql);
             	st.setInt(1, lecture.getId());
             	st.setString(2, lecture.getName());
             	st.setInt(3, lecture.getNumberOfPoints());
             	st.setInt(4, lecture.getCourseId());
            	st.execute();
           
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
    }
}
