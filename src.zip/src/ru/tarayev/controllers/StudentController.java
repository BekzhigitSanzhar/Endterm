package ru.tarayev.controllers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import com.company.data.interfaces.IDB;


import ru.tarayev.entity.Student;
import ru.tarayev.entity.quality.Lecture;



public class StudentController {
	private IDB db;
	
	public StudentController(IDB db) {
		this.db = db;
	}
	public void addStudent(Student student) {
        Connection con = null;
        try {
            con = db.getConnection();
            String sql = "INSERT INTO students(student_id, student_name, student_password, student_points, student_numberOfLectures, course_id) VALUES (?,?,?,?,?,?)";
            PreparedStatement st = con.prepareStatement(sql);
            for(int i = 0; i < student.getIdOfCourses().size(); i++) {
            	st.setInt(1, student.getId());
            	st.setString(2, student.getName());
            	st.setString(3, student.getPassword());
            	st.setInt(4, student.getPoints());
            	st.setInt(5, student.getNumberOfLectures());
            	st.setInt(6, student.getIdOfCourses().get(i));
            	st.execute();
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
    }
	public void addPoints(int id, int points) {
        Connection con = null;
        try {
            con = db.getConnection();
            String sql = "UPDATE students SET student_points = student_points + ? WHERE student_id=?";
            PreparedStatement st = con.prepareStatement(sql);

            st.setInt(1, points);
            st.setInt(2, id);
            
            st.execute();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
    }
	public void withdrawal(int id, int points) {
        Connection con = null;
        try {
            con = db.getConnection();
            String sql = "UPDATE students SET student_points = student_points - ? WHERE student_id=?";
            PreparedStatement st = con.prepareStatement(sql);

            st.setInt(1, points);
            st.setInt(2, id);
       
            st.execute();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
    }
	public Lecture getLecture(int id) {
        Connection con = null;
        try {
            con = db.getConnection();
            String sql = "SELECT * FROM students WHERE student_id=?";
            PreparedStatement st = con.prepareStatement(sql);

            st.setInt(1, id);
            ResultSet rs = st.executeQuery();
            
            
            if (rs.next()) {
            	Lecture lecture = new Lecture(rs.getInt("lecture_id"), 
            			rs.getString("lecture_name"), 
            			rs.getInt("course_id"), rs.getInt("lecture_numberOfPoints"));
                return lecture;
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
        return null;
    }
	public Student getStudent(int id) {
        Connection con = null;
        try {
            con = db.getConnection();
            String sql = "SELECT * FROM students WHERE student_id=?";
            PreparedStatement st = con.prepareStatement(sql);

            st.setInt(1, id);
            ResultSet rs = st.executeQuery();
            List<Integer> integers = new ArrayList<Integer>();
            
            if (rs.next()) {
            	integers.add(rs.getInt("course_id"));
            	Student student = new Student(id, rs.getString("student_name"), 
            			rs.getString("student_password"), rs.getInt("student_points"), 
            			rs.getInt("student_numberOfLectures"), integers);
                return student;
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
        return null;
    }
	public List<Lecture> getAllLectures(int idOfCourse) {
		
		 Connection con = null;
	        try {
	            con = db.getConnection();
	            String sql = "SELECT * FROM lectures WHERE course_id=?";
	            PreparedStatement st = con.prepareStatement(sql);
	            st.setInt(1, idOfCourse);
	            st.execute();
	            ResultSet rs = st.executeQuery(sql);
	            List<Lecture> lectures = new LinkedList<>();
	            while (rs.next()) {
	            	Lecture lecture = new Lecture(rs.getInt("lecture_id"), 
	            			rs.getString("lecture_name"), 
	            			idOfCourse, rs.getInt("lecture_numberOfPoints"));

	            	lectures.add(lecture);
	            }
	            return lectures;
	        } catch (SQLException throwables) {
	            throwables.printStackTrace();
	        } catch (ClassNotFoundException e) {
	            e.printStackTrace();
	        } finally {
	            try {
	                con.close();
	            } catch (SQLException throwables) {
	                throwables.printStackTrace();
	            }
	        }
	        return null;
	    }
	
}
