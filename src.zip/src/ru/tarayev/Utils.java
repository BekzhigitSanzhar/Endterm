package ru.tarayev;

public class Utils {
	public static int checkInt(Integer number) {
		try {
			if(number instanceof Integer) 
				return number;
		} catch(Exception e) {
			System.out.println("Wrong number!");
		}
		return 0;
	}
}
