package ru.tarayev.applications;

import java.util.Scanner;

import ru.tarayev.controllers.StudentController;
import ru.tarayev.controllers.TeacherController;

public class Application {
	private StudentController controller;
	private TeacherController tcontroller;
	public Application(StudentController controller, TeacherController tcontroller) {
		this.controller = controller;
		this.tcontroller = tcontroller;
	}
	public void start() {
		Scanner scanner = new Scanner(System.in);
		int input;
		while(true) {
			System.out.println("Send me 1 if you want to be teacher \n Or 2 if 2 - student");
			input = scanner.nextInt();
			switch(input) {
			case 1:
				this.startTeacher(scanner);
				break;
			case 2:
				this.startStudent(scanner);
				break;
			default:
				System.out.println("Exit from program...");
				return;
			}
		}
	}
	
	
	
	public void startStudent(Scanner scanner) {
		System.out.println("Send me 1 if you want to create account \n Or 2 if you want sign up");
		StudentApplication app = new StudentApplication(this.controller);
		int choose;
		while(true) {
			choose = scanner.nextInt();
			switch(choose) {
			case 1:
				app.createAccount(scanner);
				break;
			case 2:
				int id = 0;
				if(app.loginToAccount(scanner, id)) {
					app.openMenuOfStudent(scanner, id);
				} else {
					System.out.println("Password is not correct");
				}
				break;
			default:
				System.out.println("Back to the main menu");
				return;
			}
		}
	}
	
	public void startTeacher(Scanner scanner) {
		TeacherApplication app = new TeacherApplication(this.tcontroller);
		int id = 0;
		if(app.loginToAccount(scanner, id)) {
			System.out.println("Sucsessfully logged!");
			app.openTeacherMenu(scanner, id);
		} else {
			System.out.println("Error login");
			return;
		}
		
	}
}
