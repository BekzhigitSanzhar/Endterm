package ru.tarayev.applications;

import java.util.Random;
import java.util.Scanner;

import ru.tarayev.Utils;
import ru.tarayev.controllers.StudentController;
import ru.tarayev.controllers.TeacherController;
import ru.tarayev.entity.Teacher;
import ru.tarayev.entity.quality.Lecture;
 

public class TeacherApplication {
	private TeacherController controller;
	public TeacherApplication(TeacherController controller) {
		this.controller = controller;
	}
	public boolean loginToAccount(Scanner scanner, int id2) {
		System.out.println("Write your id and password");
		int id = scanner.nextInt();
		Utils.checkInt(id);
		String password = scanner.next();
		Teacher teacher = this.controller.getTeacher(id);
		if(password.equals(teacher.getPassword())) {
			System.out.println("Sucsessful login!");
			id2 = teacher.getId();
			return true;
		}
		return false;
	}
	public void openTeacherMenu(Scanner scanner, int id) {
		System.out.println("1 - add lecture \n 2 - calculate your salary");
		int number;
		while(true) {
			number = scanner.nextInt();
			switch(number) {
			case 1:
				System.out.println("Send name of your lecture");
				String name = scanner.next();
				System.out.println("Write courseId of your lecture");
				int courseId = scanner.nextInt();
				System.out.println("Write price of your lecture");
				int numberOfPoints = scanner.nextInt();
				
				Lecture lecture = new Lecture(new Random().nextInt(9999), name, courseId, numberOfPoints);
				this.controller.addLecture(lecture);
				System.out.println("Lecture has been added!");
				System.out.println(lecture.toString());
				break;
			case 2:
				Teacher teacher = this.controller.getTeacher(id);
				System.out.println("Your salary: " + (teacher.getPoints() * 20)); 
				break;
			default:
				System.out.println("Close menu");
				return;
			}
		}
	}
}
