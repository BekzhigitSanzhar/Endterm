package ru.tarayev.applications;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import ru.tarayev.Utils;
import ru.tarayev.controllers.StudentController;
import ru.tarayev.entity.Student;
import ru.tarayev.entity.quality.Lecture;

public class StudentApplication {
	private StudentController controller;
	public StudentApplication(StudentController controller) {
		this.controller = controller;
	}
	public void createAccount(Scanner scanner) {
		System.out.println("Hello! It is register menu, please, send me a user name!");
		String name = scanner.next();
		System.out.println("Ok! Please, write your password");
		String password = scanner.next();
		int points = 50;
		int numberOfLectures = 0;
		System.out.println("Ok, write a number of your courses and this ID's");
		int number = scanner.nextInt();
		Utils.checkInt(number);
		List<Integer> list = new ArrayList<Integer>();
		for(int i = 0; i < number; i++) {
			int num = scanner.nextInt();
			Utils.checkInt(number);
			list.add(num);
			System.out.println("id of course are added!");
		}
		Student student = new Student(new Random().nextInt(99999), name, password, points, numberOfLectures, list);
		this.controller.addStudent(student);
		System.out.println(student.toString());
		System.out.println("Account are created!");
	}
	public boolean loginToAccount(Scanner scanner, int ID) {
		System.out.println("Write me your id and password");
		int id = Utils.checkInt(scanner.nextInt());
		String password = scanner.next();
		
		Student student = this.controller.getStudent(id);
		
		if(student != null && password.equals(student.getPassword())) {
			System.out.println("Sucsessful login!");
			ID = student.getId();
			return true;
		}
		return false;
	}
	public void openMenuOfStudent(Scanner scanner, int id) {
		int number;
		while(true) {
			System.out.println("It is a menu of students!");
			System.out.println("1 - check lecture of course id \n 2 - check of test and gets points \n 3 - exit");
			number = Utils.checkInt(scanner.nextInt());
			switch(number) {
			case 1:
				this.menuLectures(scanner, id);
				break;
			case 2:
				this.gameOfStudent(scanner, id);
				break;
			default:
				System.out.println("Exit to menu student");
				return;
			}
			
		}
	}
	public void menuLectures(Scanner scanner, int id) {
		Student student = this.controller.getStudent(id);
		for(int i = 0; i < student.getIdOfCourses().size(); i++) {
			System.out.println("Course id: " + student.getIdOfCourses().get(i));
			for(int j = 0; j < this.controller.getAllLectures(student.getIdOfCourses().get(i)).size(); j++) {
				System.out.println("Lecture: " + this.controller.getAllLectures(student.getIdOfCourses().get(i)).get(j));
			}
		}
		System.out.println("Send me id of lecture if you just need to check it");
		int pr = scanner.nextInt();
		Lecture lecture = this.controller.getLecture(pr);
		System.out.println("Price of lecture: " + lecture.getNumberOfPoints());
		System.out.println("Are you want to buy this lecture? (Yes/No)");
		String choose = scanner.next();
		if(choose.equalsIgnoreCase("yes") && student.getPoints() - lecture.getNumberOfPoints() >= 0) {
			student.setPoints(student.getPoints() - lecture.getNumberOfPoints());
			this.controller.withdrawal(id, lecture.getNumberOfPoints());
		} else {
			System.out.println("Execute error!");
		}
	}
	public void gameOfStudent(Scanner scanner, int id) {
		System.out.println("Can you send me number, which you need to stay on AFK (1 - 10 sec)");
		int number = scanner.nextInt();
		for(int i = 0; i < number; i++) {
			try {
				Thread.sleep(10000L);
				this.controller.addPoints(id, 10);
				System.out.println("Added 10 points!");
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}
